const mongoose = require("mongoose");

const connectDB = async () => {
    try {
        await mongoose.connect(
            process.env.mongo_uri
        );

        console.log(
            "MongoDB Connected"
        );
    } catch (error) {
        console.log(error.message);
        process.exit(1);
    }
};

module.exports = connectDB;