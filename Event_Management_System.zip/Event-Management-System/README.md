# Event Management System

## Project Overview

The Event Management System is a backend application developed using Node.js, Express.js, MongoDB, and Mongoose. It provides RESTful APIs for managing organizers, venues, events, participants, and registrations. The system also includes JWT-based authentication and authorization for secure access to protected routes.


## Technologies Used

### Backend

* Node.js
* Express.js

### Database

* MongoDB
* Mongoose

### Authentication

* JSON Web Token (JWT)
* bcryptjs

### Other Packages

* dotenv
* cors

### API Testing

* Postman

---

## Features

* Organizer Management (CRUD)
* Venue Management (CRUD)
* Event Management (CRUD)
* Participant Management (CRUD)
* Registration Management (CRUD)
* JWT Authentication
* Password Hashing
* Protected Routes
* MongoDB Database Integration
* RESTful API Architecture

---

## Installation

### Clone or Extract the Project

Navigate to the project folder:

```bash
cd Event-Management-System
```

### Install Dependencies

```bash
npm install
```

---

## Environment Variables

Create a `.env` file in the root directory and add:

```env
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/event_management_system
JWT_SECRET=mysecretkey123
```

---

## Run the Application

```bash
node app.js
```

or

```bash
npm start
```

Expected output:

```text
MongoDB Connected
Server Running on Port 5000
```

---

## API Endpoints

### Authentication

 Method  Endpoint           
 ------  ------------------ 
 POST    /api/auth/register 
 POST    /api/auth/login    
 GET     /api/auth/users    

### Organizers

 Method  Endpoint            
 ------  ------------------- 
 POST    /api/organizers     
 GET     /api/organizers     
 GET     /api/organizers/:id 
 PUT     /api/organizers/:id 
 DELETE  /api/organizers/:id 

### Venues

 Method  Endpoint        
 ------  --------------- 
 POST    /api/venues     
 GET     /api/venues     
 GET     /api/venues/:id 
 PUT     /api/venues/:id 
 DELETE  /api/venues/:id 

### Events

 Method  Endpoint        
 ------  --------------- 
 POST    /api/events     
 GET     /api/events     
 GET     /api/events/:id 
 PUT     /api/events/:id 
 DELETE  /api/events/:id 

### Participants

 Method  Endpoint              
 ------  --------------------- 
 POST    /api/participants     
 GET     /api/participants     
 GET     /api/participants/:id 
 PUT     /api/participants/:id 
 DELETE  /api/participants/:id 

### Registrations

 Method  Endpoint               
 ------  ---------------------- 
 POST    /api/registrations     
 GET     /api/registrations     
 GET     /api/registrations/:id 
 DELETE  /api/registrations/:id 

---

## Authentication

After successful login, copy the JWT token and include it in request headers:

```text
Authorization: Bearer <your_token>
```

---

## Database Collections

* users
* organizers
* venues
* events
* participants
* registrations

---

## Conclusion

The Event Management System demonstrates backend development concepts including REST API design, MongoDB integration, authentication, authorization, CRUD operations, and relationship mapping between multiple entities.
