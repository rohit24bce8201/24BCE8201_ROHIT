const mongoose = require("mongoose");

const eventSchema = new mongoose.Schema({
    eventName: {
        type: String,
        required: true
    },

    eventDate: {
        type: Date,
        required: true
    },

    organizerId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Organizer",
        required: true
    },

    venueId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Venue",
        required: true
    }
}, {
    timestamps: true
});

module.exports = mongoose.model(
    "Event",
    eventSchema
);