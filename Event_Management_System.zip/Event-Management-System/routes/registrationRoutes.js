const express = require("express");

const router = express.Router();

const {
    createRegistration,
    getRegistrations,
    deleteRegistration,
    getParticipantsByEvent,
    getEventsByParticipant
} = require(
    "../controllers/registrationController"
);

router.post("/", createRegistration);

router.get("/", getRegistrations);

router.delete(
    "/:id",
    deleteRegistration
);

router.get(
    "/event/:eventId",
    getParticipantsByEvent
);

router.get(
    "/participant/:participantId",
    getEventsByParticipant
);

module.exports = router;