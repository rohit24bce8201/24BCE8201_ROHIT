const express = require("express");

const router = express.Router();
const User = require("../models/User")
const {
    registerUser,
    loginUser
} = require(
    "../controllers/authController"
);

router.post(
    "/register",
    registerUser
);

router.post(
    "/login",
    loginUser
);
router.get("/users", async (req, res) => {
    const users = await User.find().select("-password")
    res.json(users)
})
module.exports = router;