const Organizer =
    require("../models/Organizer");

const createOrganizer =
    async (req, res) => {
        try {

            const organizer =
                await Organizer.create(
                    req.body
                );

            res.status(201).json(
                organizer
            );

        } catch (error) {

            res.status(500).json({
                message:
                    error.message
            });

        }
    };

const getOrganizers =
    async (req, res) => {

        try {

            const organizers =
                await Organizer.find();

            res.json(
                organizers
            );

        } catch (error) {

            res.status(500).json({
                message:
                    error.message
            });

        }
    };

const getOrganizerById =
    async (req, res) => {

        try {

            const organizer =
                await Organizer.findById(
                    req.params.id
                );

            if (!organizer) {

                return res.status(404)
                    .json({
                        message:
                            "Organizer not found"
                    });

            }

            res.json(
                organizer
            );

        } catch (error) {

            res.status(500).json({
                message:
                    error.message
            });

        }
    };

const updateOrganizer =
    async (req, res) => {

        try {

            const organizer =
                await Organizer.findByIdAndUpdate(
                    req.params.id,
                    req.body,
                    {
                        new: true
                    }
                );

            res.json(
                organizer
            );

        } catch (error) {

            res.status(500).json({
                message:
                    error.message
            });

        }
    };

const deleteOrganizer =
    async (req, res) => {

        try {

            await Organizer.findByIdAndDelete(
                req.params.id
            );

            res.json({
                message:
                    "Organizer deleted successfully"
            });

        } catch (error) {

            res.status(500).json({
                message:
                    error.message
            });

        }
    };

module.exports = {
    createOrganizer,
    getOrganizers,
    getOrganizerById,
    updateOrganizer,
    deleteOrganizer
};