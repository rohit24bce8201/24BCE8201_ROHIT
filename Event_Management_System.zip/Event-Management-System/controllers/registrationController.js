const Registration =
    require("../models/Registration");
const createRegistration =
    async (req, res) => {

        try {

            const {
                participantId,
                eventId
            } = req.body;

            const existing =
                await Registration.findOne({
                    participantId,
                    eventId
                });

            if (existing) {
                return res.status(400).json({
                    message:
                        "Participant already registered"
                });
            }

            const registration =
                await Registration.create({
                    participantId,
                    eventId
                });

            res.status(201).json(
                registration
            );

        } catch (error) {

            res.status(500).json({
                message:
                    error.message
            });

        }
    };
const getRegistrations =
    async (req, res) => {

        try {

            const registrations =
                await Registration.find()
                    .populate("participantId")
                    .populate("eventId");

            res.json(registrations);

        } catch (error) {

            res.status(500).json({
                message:
                    error.message
            });

        }
    };
const deleteRegistration =
    async (req, res) => {

        try {

            await Registration.findByIdAndDelete(
                req.params.id
            );

            res.json({
                message:
                    "Registration deleted successfully"
            });

        } catch (error) {

            res.status(500).json({
                message:
                    error.message
            });

        }
    };
const getParticipantsByEvent =
    async (req, res) => {

        try {

            const registrations =
                await Registration.find({
                    eventId:
                        req.params.eventId
                })
                    .populate(
                        "participantId"
                    );

            res.json(registrations);

        } catch (error) {

            res.status(500).json({
                message:
                    error.message
            });

        }
    };
const getEventsByParticipant =
    async (req, res) => {

        try {

            const registrations =
                await Registration.find({
                    participantId:
                        req.params.participantId
                })
                    .populate("eventId");

            res.json(registrations);

        } catch (error) {

            res.status(500).json({
                message:
                    error.message
            });

        }
    };
module.exports = {
    createRegistration,
    getRegistrations,
    deleteRegistration,
    getParticipantsByEvent,
    getEventsByParticipant
};