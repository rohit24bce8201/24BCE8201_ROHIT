const Participant =
    require("../models/Participant");

const createParticipant =
    async (req, res) => {
        try {
            const participant =
                await Participant.create(
                    req.body
                );

            res.status(201).json(
                participant
            );

        } catch (error) {
            res.status(500).json({
                message: error.message
            });
        }
    };

const getParticipants =
    async (req, res) => {
        try {
            const participants =
                await Participant.find();

            res.json(participants);

        } catch (error) {
            res.status(500).json({
                message: error.message
            });
        }
    };

const getParticipantById =
    async (req, res) => {
        try {
            const participant =
                await Participant.findById(
                    req.params.id
                );

            if (!participant) {
                return res.status(404).json({
                    message:
                        "Participant not found"
                });
            }

            res.json(participant);

        } catch (error) {
            res.status(500).json({
                message: error.message
            });
        }
    };

const updateParticipant =
    async (req, res) => {
        try {
            const participant =
                await Participant.findByIdAndUpdate(
                    req.params.id,
                    req.body,
                    { new: true }
                );

            res.json(participant);

        } catch (error) {
            res.status(500).json({
                message: error.message
            });
        }
    };

const deleteParticipant =
    async (req, res) => {
        try {
            await Participant.findByIdAndDelete(
                req.params.id
            );

            res.json({
                message:
                    "Participant deleted successfully"
            });

        } catch (error) {
            res.status(500).json({
                message: error.message
            });
        }
    };

module.exports = {
    createParticipant,
    getParticipants,
    getParticipantById,
    updateParticipant,
    deleteParticipant
};