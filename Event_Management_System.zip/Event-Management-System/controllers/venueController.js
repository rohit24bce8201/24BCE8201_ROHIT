const Venue = require("../models/Venue");

const createVenue = async (req, res) => {
    try {
        const venue = await Venue.create(req.body);
        res.status(201).json(venue);
    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};

const getVenues = async (req, res) => {
    try {
        const venues = await Venue.find();
        res.json(venues);
    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};

const getVenueById = async (req, res) => {
    try {
        const venue = await Venue.findById(
            req.params.id
        );

        if (!venue) {
            return res.status(404).json({
                message: "Venue not found"
            });
        }

        res.json(venue);
    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};

const updateVenue = async (req, res) => {
    try {
        const venue =
            await Venue.findByIdAndUpdate(
                req.params.id,
                req.body,
                { new: true }
            );

        res.json(venue);
    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};

const deleteVenue = async (req, res) => {
    try {
        await Venue.findByIdAndDelete(
            req.params.id
        );

        res.json({
            message:
                "Venue deleted successfully"
        });
    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};

module.exports = {
    createVenue,
    getVenues,
    getVenueById,
    updateVenue,
    deleteVenue
};