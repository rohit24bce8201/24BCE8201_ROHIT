require("dotenv").config();

const express = require("express");
const cors = require("cors");
const authRoutes =
    require("./routes/authRoutes");
const connectDB =
    require("./config/db");

const app = express();

connectDB();

app.use(express.json());
app.use(cors());

app.get("/", (req, res) => {
    res.send(
        "Event Management API Running"
    );
});

const PORT =
    process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(
        `Server running on port ${PORT}`
    );
});

const organizerRoutes =
    require(
        "./routes/organizerRoutes"
    );

app.use(
    "/api/organizers",
    organizerRoutes
);

const venueRoutes =
    require("./routes/venueRoutes");
app.use(
    "/api/venues",
    venueRoutes
);

const participantRoutes =
    require(
        "./routes/participantRoutes"
    );
app.use(
    "/api/participants",
    participantRoutes
);

const eventRoutes =
    require("./routes/eventRoutes");
app.use(
    "/api/events",
    eventRoutes
);

const registrationRoutes =
    require(
        "./routes/registrationRoutes"
    );

app.use(
    "/api/registrations",
    registrationRoutes
);
app.use(
    "/api/auth",
    authRoutes
);